package lab3;
/**
 * 
 * @author frankxu
 *
 */
public abstract class ChessPiece {
	private int value;
	
	/**
	 * 
	 * @param value value of ChessPiece
	 */
	public ChessPiece(int value) {
		this.value = value;
	}
	
	
	/**
	 * 
	 * @param value set value
	 */
	public final void setValue(int value) {
		this.value = value;
	}
	
	/**
	 * return value
	 * @return return value
	 */
	public int getValue() {
		return value;
	}
	
	public abstract void move(); 
	
	@Override
	public String toString() {
		return "value is " + this.getValue();
	}

}


