package lab3;

public class King extends ChessPiece {

	public King() {
		super(1000);
	}
	
	@Override
	public void move() {
		System.out.println("like a bishop or a rook");
	}
}
