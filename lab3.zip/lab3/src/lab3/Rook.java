package lab3;

public class Rook extends ChessPiece {

	public Rook() {
		super(5);
	}
	
	@Override
	public void move() {
		System.out.println("horizontally or vertically");
	}
}
