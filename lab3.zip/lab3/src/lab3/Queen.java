package lab3;

public class Queen extends ChessPiece {

	public Queen() {
		super(9);
	}

	@Override
	public void move() {
		System.out.println("one square");
	}
}
