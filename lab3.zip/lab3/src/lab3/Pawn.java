package lab3;

public class Pawn extends ChessPiece {
	private boolean hasBeenPromoted;
	private ChessPiece newPiece;

	public Pawn() {
		super(1);
	}

	public void promote(ChessPiece newPiece) {
		if (newPiece.getValue() != 1 && newPiece.getValue() != 1000) {
			this.hasBeenPromoted = true;
			this.newPiece = newPiece;
		}
	}

	/**
	 * @return the hasBeenPromoted
	 */
	public boolean isHasBeenPromoted() {
		return hasBeenPromoted;
	}

	/**
	 * @param hasBeenPromoted the hasBeenPromoted to set
	 */
	public void setHasBeenPromoted(boolean hasBeenPromoted) {
		this.hasBeenPromoted = hasBeenPromoted;
	}

	/**
	 * @return the newPiece
	 */
	public ChessPiece getNewPiece() {
		return newPiece;
	}

	/**
	 * @param newPiece the newPiece to set
	 */
	public void setNewPiece(ChessPiece newPiece) {
		this.newPiece = newPiece;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		
		Pawn other = (Pawn) obj;
		if (this.hasBeenPromoted != other.hasBeenPromoted) {
			return false;
		}
		
		if (newPiece == null) {
			if (other.newPiece != null) {
				return false;
			}
		} else if (!newPiece.equals(other.newPiece)) {
			return false;
		}

		return true;
	}

	@Override
	public void move() {
		System.out.println("foward 1");
	}
	
	@Override
	public String toString() {
		return "value is " + this.getValue() + " and new piece: " + this.getNewPiece() + ". Has been promted: " + this.isHasBeenPromoted();
	}
}
