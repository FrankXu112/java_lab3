package lab3;

public class Driver {
	public static void main(String[] args) {
		ChessPiece queen  = new Queen();
		ChessPiece king = new King();
		ChessPiece bishop = new Bishop();
		ChessPiece rook = new Rook();
		ChessPiece knight = new Rook();
		Pawn pawn1 = new Pawn();
		Pawn pawn2 = new Pawn();
		Pawn pawn3 = new Pawn();
		Pawn pawn4 = new Pawn();
		
		System.out.println(queen.equals(king));
		System.out.println(rook.equals(knight));
		
		pawn1.promote(knight);
		pawn4.promote(bishop);
		System.out.println(pawn1);
		System.out.println(pawn2);
		
		System.out.println(pawn1.equals(pawn2));
		System.out.println(pawn1.equals(king));
		System.out.println(pawn2.equals(pawn3));
		System.out.println(pawn1.equals(pawn4));
	}
}
